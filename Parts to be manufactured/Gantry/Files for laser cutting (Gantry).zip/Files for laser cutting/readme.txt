Author: Wei Ting Teo and Kenji Komori Wong
Date: 16/12/23

This .zip file contains 2 unique objectss for manufacturing components used to build the gantry.

The files contained within are listed below:
-bottomhingeholder.ipt
-bottomhingeholder.stp
-bottomhingeholder.stl

-slothinge.ipt
-slothinge.stp
-slothinge.stl

*.ipt = Autodesk Inventor part file, exported from Autodesk Inventor 2024
*.stp = STEP file, exported using 214 protocol
*.stl = Standard tesselation language