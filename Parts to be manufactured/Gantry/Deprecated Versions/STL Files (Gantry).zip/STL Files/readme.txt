Author: Wei Ting Teo and Kenji Komori Wong
Date: 16/12/23

This .zip file contains 26 .stl files for manufacturing components used to build the gantry.
The files contained within are listed below:
-5885spacer.stl
-bottomhinge.stl
-bottomhingeinsert.stl
-bottomhingesingle.stl
-motormounttension.stl
-tensionknob.stl
-tophinge.stl
-Xbearingholder.stl
-Xslidingbottom.stl
-Xslidingmiddle.stl
-Xslidingtop.stl
-Yaxisendcap.stl
-Yaxisfrontcap.stl
-Ydrivenrack.stl
-Ydrivingpinion.stl
-Z80Tgear.stl
-Zbeltclamp.stl
-Zbottombearingholder.stl
-Zbottombearingholder2.stl
-Zmotorhousing.stl
-Zsliding_LI.stl
-Zsliding_LO.stl
-Zsliding_RI.stl
-Zsliding_RO.stl
-Ztopbearingholder.stl

