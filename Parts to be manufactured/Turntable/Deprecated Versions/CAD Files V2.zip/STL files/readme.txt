Author: Wei Ting Teo and Kenji Komori Wong
Date: 16/12/23

This .zip file contains 9 unique .stl files for manufacturing components used to build the gantry.

The files contained within are listed below:
-chassisclip.stl
-drivenHgear1.stl
-drivenHgear2.stl
-drivenHgear3.stl
-drivenHgear4.stl
-drivenHgear5.stl
-drivenHgear6.stl
-drivingHbonegear.stl
-turntableleg.stl

